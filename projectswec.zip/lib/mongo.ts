// Mock MongoDB client for UI-only viewing
export async function getMongoClient() {
  return {
    db: () => ({
      collection: () => ({
        find: () => ({
          toArray: async () => [],
        }),
        findOne: async () => null,
        insertOne: async () => ({ insertedId: "mock-id" }),
        updateOne: async () => ({ modifiedCount: 1 }),
        deleteOne: async () => ({ deletedCount: 1 }),
      }),
    }),
    close: async () => {},
  }
}

export async function connectToDatabase() {
  return {
    collection: () => ({
      find: () => ({
        toArray: async () => [],
      }),
      findOne: async () => null,
      insertOne: async () => ({ insertedId: "mock-id" }),
      updateOne: async () => ({ modifiedCount: 1 }),
      deleteOne: async () => ({ deletedCount: 1 }),
    }),
  }
}

export async function getCollection() {
  return {
    find: () => ({
      toArray: async () => [],
      sort: () => ({
        toArray: async () => [],
        limit: () => ({
          toArray: async () => [],
        }),
      }),
      limit: () => ({
        toArray: async () => [],
      }),
    }),
    findOne: async () => null,
    insertOne: async () => ({ insertedId: "mock-id" }),
    updateOne: async () => ({ modifiedCount: 1 }),
    deleteOne: async () => ({ deletedCount: 1 }),
    countDocuments: async () => 0,
  }
}

export async function disconnectFromDatabase() {
  return
}
