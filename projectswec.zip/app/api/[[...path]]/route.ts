import { type NextRequest, NextResponse } from "next/server"
import {
  mockCandidates,
  mockCompanies,
  mockOffers,
  mockDrives,
  mockDepartments,
  mockEvents,
  mockScheduledDrives,
  mockSWECOffers,
} from "@/lib/mock-data"

export async function GET(request: NextRequest, { params }: { params: { path?: string[] } }) {
  const path = params.path || []
  const endpoint = path[0]

  // Return mock data based on the endpoint
  switch (endpoint) {
    case "candidates":
      return NextResponse.json(mockCandidates)
    case "companies":
      return NextResponse.json(mockCompanies)
    case "offers":
      return NextResponse.json(mockOffers)
    case "drives":
      return NextResponse.json(mockDrives)
    case "departments":
      return NextResponse.json(mockDepartments)
    case "events":
      return NextResponse.json(mockEvents)
    case "scheduled-drives":
      return NextResponse.json(mockScheduledDrives)
    case "swec-offers":
      return NextResponse.json(mockSWECOffers)
    default:
      return NextResponse.json({ message: "Mock API endpoint" })
  }
}

export async function POST(request: NextRequest) {
  // For demo purposes, just return success with a mock ID
  return NextResponse.json({ id: "mock-" + Date.now(), success: true }, { status: 201 })
}

export async function PUT(request: NextRequest) {
  // For demo purposes, just return success
  return NextResponse.json({ success: true })
}

export async function PATCH(request: NextRequest) {
  // For demo purposes, just return success
  return NextResponse.json({ success: true })
}

export async function DELETE(request: NextRequest) {
  // For demo purposes, just return success
  return NextResponse.json({ success: true })
}
