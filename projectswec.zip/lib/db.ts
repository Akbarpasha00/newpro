// Mock implementation of db.ts that doesn't require MongoDB
import {
  mockCandidates,
  mockCompanies,
  mockOffers,
  mockDrives,
  mockDepartments,
  mockEvents,
  mockScheduledDrives,
  mockSWECOffers,
  mockUsers,
} from "./mock-data"

// Collection names
export const collections = {
  CANDIDATES: "candidates",
  COMPANIES: "companies",
  OFFERS: "offers",
  DRIVES: "drives",
  DEPARTMENTS: "departments",
  EVENTS: "events",
  SCHEDULED_DRIVES: "scheduledDrives",
  SWEC_OFFERS: "swecOffers",
  USERS: "users",
  DRIVE_REGISTRATIONS: "driveRegistrations",
  REFERRALS: "referrals",
}

// Helper functions
export async function findOne(collection: string, query: any) {
  let data: any[] = []

  switch (collection) {
    case collections.CANDIDATES:
      data = mockCandidates
      break
    case collections.COMPANIES:
      data = mockCompanies
      break
    case collections.OFFERS:
      data = mockOffers
      break
    case collections.DRIVES:
      data = mockDrives
      break
    case collections.DEPARTMENTS:
      data = mockDepartments
      break
    case collections.EVENTS:
      data = mockEvents
      break
    case collections.SCHEDULED_DRIVES:
      data = mockScheduledDrives
      break
    case collections.SWEC_OFFERS:
      data = mockSWECOffers
      break
    case collections.USERS:
      data = mockUsers
      break
    default:
      return null
  }

  // Simple query matching
  if (query._id) {
    return data.find((item) => item._id === query._id)
  }
  if (query.email) {
    return data.find((item) => item.email === query.email)
  }

  // Return first item as fallback
  return data[0]
}

export async function findMany(collection: string) {
  switch (collection) {
    case collections.CANDIDATES:
      return mockCandidates
    case collections.COMPANIES:
      return mockCompanies
    case collections.OFFERS:
      return mockOffers
    case collections.DRIVES:
      return mockDrives
    case collections.DEPARTMENTS:
      return mockDepartments
    case collections.EVENTS:
      return mockEvents
    case collections.SCHEDULED_DRIVES:
      return mockScheduledDrives
    case collections.SWEC_OFFERS:
      return mockSWECOffers
    case collections.USERS:
      return mockUsers
    default:
      return []
  }
}

export async function insertOne(collection: string, data: any) {
  // Generate a mock ID
  const id = Math.random().toString(36).substring(2, 15)
  return { _id: id, ...data }
}

export async function updateOne(collection: string, id: string, data: any) {
  return { _id: id, ...data }
}

export async function deleteOne(collection: string, id: string) {
  return { _id: id }
}

export async function findById(collection: string, id: string) {
  let data: any[] = []

  switch (collection) {
    case collections.CANDIDATES:
      data = mockCandidates
      break
    case collections.COMPANIES:
      data = mockCompanies
      break
    case collections.OFFERS:
      data = mockOffers
      break
    case collections.DRIVES:
      data = mockDrives
      break
    case collections.DEPARTMENTS:
      data = mockDepartments
      break
    case collections.EVENTS:
      data = mockEvents
      break
    case collections.SCHEDULED_DRIVES:
      data = mockScheduledDrives
      break
    case collections.SWEC_OFFERS:
      data = mockSWECOffers
      break
    case collections.USERS:
      data = mockUsers
      break
    default:
      return null
  }

  return data.find((item) => item._id === id)
}

export async function getCandidateById(id: string) {
  return findById(collections.CANDIDATES, id)
}

// Mock DB implementation - now exported as a named export
export const db = {
  candidates: {
    findMany: async () => mockCandidates,
    findOne: async (query: any = {}) => {
      if (query.where?.id) {
        return mockCandidates.find((c) => c._id === query.where.id) || mockCandidates[0]
      }
      return mockCandidates[0]
    },
    create: async (data: any) => ({ _id: "mock-id", ...data.data }),
    update: async (query: any) => ({ _id: query.where.id, ...query.data }),
    delete: async (query: any) => ({ _id: query.where.id }),
  },
  companies: {
    findMany: async () => mockCompanies,
    findOne: async (query: any = {}) => {
      if (query.where?.id) {
        return mockCompanies.find((c) => c._id === query.where.id) || mockCompanies[0]
      }
      return mockCompanies[0]
    },
    create: async (data: any) => ({ _id: "mock-id", ...data.data }),
    update: async (query: any) => ({ _id: query.where.id, ...query.data }),
    delete: async (query: any) => ({ _id: query.where.id }),
  },
  offers: {
    findMany: async () => mockOffers,
    findOne: async (query: any = {}) => {
      if (query.where?.id) {
        return mockOffers.find((o) => o._id === query.where.id) || mockOffers[0]
      }
      return mockOffers[0]
    },
    create: async (data: any) => ({ _id: "mock-id", ...data.data }),
    update: async (query: any) => ({ _id: query.where.id, ...query.data }),
    delete: async (query: any) => ({ _id: query.where.id }),
  },
  drives: {
    findMany: async () => mockDrives,
    findOne: async (query: any = {}) => {
      if (query.where?.id) {
        return mockDrives.find((d) => d._id === query.where.id) || mockDrives[0]
      }
      return mockDrives[0]
    },
    create: async (data: any) => ({ _id: "mock-id", ...data.data }),
    update: async (query: any) => ({ _id: query.where.id, ...query.data }),
    delete: async (query: any) => ({ _id: query.where.id }),
  },
  departments: {
    findMany: async () => mockDepartments,
    findOne: async (query: any = {}) => {
      if (query.where?.id) {
        return mockDepartments.find((d) => d._id === query.where.id) || mockDepartments[0]
      }
      return mockDepartments[0]
    },
    create: async (data: any) => ({ _id: "mock-id", ...data.data }),
    update: async (query: any) => ({ _id: query.where.id, ...query.data }),
    delete: async (query: any) => ({ _id: query.where.id }),
  },
  events: {
    findMany: async () => mockEvents,
    findOne: async (query: any = {}) => {
      if (query.where?.id) {
        return mockEvents.find((e) => e._id === query.where.id) || mockEvents[0]
      }
      return mockEvents[0]
    },
    create: async (data: any) => ({ _id: "mock-id", ...data.data }),
    update: async (query: any) => ({ _id: query.where.id, ...query.data }),
    delete: async (query: any) => ({ _id: query.where.id }),
  },
  scheduledDrives: {
    findMany: async () => mockScheduledDrives,
    findOne: async (query: any = {}) => {
      if (query.where?.id) {
        return mockScheduledDrives.find((d) => d._id === query.where.id) || mockScheduledDrives[0]
      }
      return mockScheduledDrives[0]
    },
    create: async (data: any) => ({ _id: "mock-id", ...data.data }),
    update: async (query: any) => ({ _id: query.where.id, ...query.data }),
    delete: async (query: any) => ({ _id: query.where.id }),
  },
  swecOffers: {
    findMany: async () => mockSWECOffers,
    findOne: async (query: any = {}) => {
      if (query.where?.id) {
        return mockSWECOffers.find((o) => o._id === query.where.id) || mockSWECOffers[0]
      }
      return mockSWECOffers[0]
    },
    create: async (data: any) => ({ _id: "mock-id", ...data.data }),
    update: async (query: any) => ({ _id: query.where.id, ...query.data }),
    delete: async (query: any) => ({ _id: query.where.id }),
  },
  referrals: {
    findMany: async () => [],
    findOne: async () => null,
    create: async (data: any) => ({ _id: "mock-id", ...data.data }),
    update: async (query: any) => ({ _id: query.where.id, ...query.data }),
    delete: async (query: any) => ({ _id: query.where.id }),
  },
  users: {
    findMany: async () => mockUsers,
    findOne: async (query: any = {}) => {
      if (query.where?.email) {
        return mockUsers.find((u) => u.email === query.where.email) || mockUsers[0]
      }
      return mockUsers[0]
    },
    create: async (data: any) => ({ _id: "mock-id", ...data.data }),
    update: async (query: any) => ({ _id: query.where.id, ...query.data }),
    delete: async (query: any) => ({ _id: query.where.id }),
  },
}

// No default export needed since we're using named exports
