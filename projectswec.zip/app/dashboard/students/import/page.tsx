"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronLeft, Upload, AlertCircle, CheckCircle, Download } from "lucide-react"
import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/components/ui/use-toast"

export default function ImportStudentsPage() {
  const [file, setFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [uploadResult, setUploadResult] = useState<{
    success: boolean
    message: string
    imported?: number
    errors?: string[]
  } | null>(null)
  const { toast } = useToast()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0]

      // Check if file is CSV
      if (!selectedFile.name.endsWith(".csv")) {
        toast({
          title: "Invalid file format",
          description: "Please upload a CSV file",
          variant: "destructive",
        })
        return
      }

      setFile(selectedFile)
      setUploadResult(null)
    }
  }

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!file) {
      toast({
        title: "No file selected",
        description: "Please select a CSV file to import",
        variant: "destructive",
      })
      return
    }

    setIsUploading(true)
    setUploadProgress(0)

    try {
      // Start progress updates
      const progressInterval = setInterval(() => {
        setUploadProgress((prev) => {
          const newProgress = prev + 5
          return newProgress >= 90 ? 90 : newProgress
        })
      }, 300)

      // For demo purposes, we'll simulate processing the file locally
      const reader = new FileReader()

      reader.onload = async (event) => {
        try {
          if (!event.target?.result) throw new Error("Failed to read file")

          const csvContent = event.target.result as string
          const rows = csvContent.split("\n")

          // Process the data (in a real app, this would be sent to the server)
          const processedData = processStudentData(rows)

          clearInterval(progressInterval)
          setUploadProgress(100)

          // Simulate API response
          setTimeout(() => {
            setUploadResult({
              success: true,
              message: "Import completed successfully",
              imported: processedData.length,
              errors: processedData.errors || [],
            })

            toast({
              title: "Import successful",
              description: `Successfully imported ${processedData.length} students`,
            })

            setIsUploading(false)
          }, 1000)
        } catch (error) {
          handleImportError(error, progressInterval)
        }
      }

      reader.onerror = (error) => {
        handleImportError(error, progressInterval)
      }

      reader.readAsText(file)
    } catch (error) {
      handleImportError(error)
    }
  }

  // Helper function to process student data
  const processStudentData = (rows: string[]) => {
    const students = []
    const errors = []

    // Skip header row
    for (let i = 1; i < rows.length; i++) {
      try {
        const row = rows[i].trim()
        if (!row) continue

        // Split by tabs or multiple spaces
        const columns = row.split(/\t+|\s{2,}/)

        if (columns.length < 5) {
          errors.push(`Row ${i}: Not enough columns (${columns.length})`)
          continue
        }

        // Extract data based on the format provided
        const student = {
          sno: columns[0],
          branch: columns[1],
          rollNo: columns[2],
          name: columns[3],
          fullName: columns[4],
          email: columns[5],
          contact: columns[6],
          offerStatus: columns.length > 7 && columns[7] !== "-" ? "Placed" : "Active",
          offers: [],
        }

        // Process offers (columns 8 onwards)
        const offerColumns = [
          "ACCENTURE",
          "DELOITTE",
          "TECH MAHINDRA",
          "CAPGEMINI",
          "COGNIZANT",
          "TEACHNOOK",
          "OPENTEXT",
          "PUBLIC SAPIENT",
          "FIDELITY",
          "SAVANTIS",
        ]

        for (let j = 0; j < offerColumns.length; j++) {
          const offerIndex = j + 8
          if (columns.length > offerIndex && columns[offerIndex] && columns[offerIndex] !== "-") {
            student.offers.push(offerColumns[j])
          }
        }

        students.push(student)
      } catch (error) {
        errors.push(`Row ${i}: ${error instanceof Error ? error.message : "Unknown error"}`)
      }
    }

    students.errors = errors
    return students
  }

  // Helper function to handle import errors
  const handleImportError = (error: any, progressInterval?: NodeJS.Timeout) => {
    console.error("Error processing file:", error)

    if (progressInterval) {
      clearInterval(progressInterval)
    }

    setUploadResult({
      success: false,
      message: error instanceof Error ? error.message : "An error occurred during import",
      errors: ["Failed to process the file. Please check the format and try again."],
    })

    toast({
      title: "Import failed",
      description: error instanceof Error ? error.message : "Failed to import students",
      variant: "destructive",
    })

    setIsUploading(false)
  }

  const handleDownloadTemplate = () => {
    // Create CSV content that matches the expected format
    const headers =
      "SNO\tBRANCH\tROLL NO\tFULL NAME\tFULL NAME\tE-Mail ID\tCONTACT\tOFFER\tACCENTURE\tDELOITTE\tTECH MAHINDRA\tCAPGEMINI\tCOGNIZANT\tTEACHNOOK\tOPENTEXT\tPUBLIC SAPIENT\tFIDELITY\tSAVANTIS\n"
    const sampleRow =
      "1\tCSE-A\t21D21A0501\tJohn Doe\tJOHN DOE\tjohn@example.com\t9876543210\tyes\tAccenture\t-\tTechM\t-\t-\tTeachnook\t-\t-\t-\t-\n"
    const csvContent = headers + sampleRow

    // Create a blob and download
    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "student-import-template.csv"
    document.body.appendChild(a)
    a.click()
    window.URL.revokeObjectURL(url)
    document.body.removeChild(a)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Import Students</h1>
        <Button variant="outline" asChild>
          <Link href="/dashboard/students">
            <ChevronLeft className="mr-2 h-4 w-4" />
            Back to Students
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>CSV Import</CardTitle>
          <CardDescription>Upload a CSV file containing student data to import into the system.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleUpload} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="csv-file">CSV File</Label>
              <Input id="csv-file" type="file" accept=".csv" onChange={handleFileChange} disabled={isUploading} />
              <p className="text-sm text-muted-foreground">
                The CSV file should have the following columns: name, email, phone, gender, branch, college, etc.
              </p>
            </div>

            {isUploading && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Uploading...</span>
                  <span className="text-sm text-muted-foreground">{uploadProgress}%</span>
                </div>
                <Progress value={uploadProgress} className="h-2" />
              </div>
            )}

            {uploadResult && (
              <Alert variant={uploadResult.success ? "default" : "destructive"}>
                {uploadResult.success ? <CheckCircle className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
                <AlertTitle>{uploadResult.success ? "Import Successful" : "Import Failed"}</AlertTitle>
                <AlertDescription>
                  <p>{uploadResult.message}</p>
                  {uploadResult.imported !== undefined && (
                    <p className="mt-2">Successfully imported {uploadResult.imported} students.</p>
                  )}
                  {uploadResult.errors && uploadResult.errors.length > 0 && (
                    <div className="mt-2">
                      <p className="font-medium">Errors:</p>
                      <ul className="ml-6 list-disc">
                        {uploadResult.errors.map((error, index) => (
                          <li key={index} className="text-sm">
                            {error}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </AlertDescription>
              </Alert>
            )}

            <div className="flex justify-end space-x-2">
              <Button
                type="button"
                variant="outline"
                disabled={isUploading}
                onClick={() => {
                  setFile(null)
                  setUploadResult(null)
                }}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={!file || isUploading}>
                {isUploading ? (
                  <>Uploading...</>
                ) : (
                  <>
                    <Upload className="mr-2 h-4 w-4" />
                    Upload and Import
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Data Format Guidelines</CardTitle>
          <CardDescription>Please ensure your CSV file follows these guidelines for successful import.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-medium">Required Format</h3>
              <p className="text-sm text-muted-foreground">Your CSV file should have the following columns in order:</p>
              <ul className="ml-6 list-disc text-sm">
                <li>SNO - Serial number</li>
                <li>BRANCH - Student's branch (e.g., CSE-A, ECE-B)</li>
                <li>ROLL NO - Student's roll number</li>
                <li>FULL NAME - Student's full name</li>
                <li>FULL NAME (repeated) - Student's full name in uppercase</li>
                <li>E-Mail ID - Student's email address</li>
                <li>CONTACT - Student's contact number</li>
                <li>OFFER - Offer status (yes/no/-)</li>
                <li>Company columns - One column for each company (ACCENTURE, DELOITTE, etc.)</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-medium">Example</h3>
              <pre className="mt-2 rounded-md bg-slate-100 p-4 text-xs">
                SNO BRANCH ROLL NO FULL NAME FULL NAME E-Mail ID CONTACT OFFER ACCENTURE DELOITTE...{"\n"}1 CSE-A
                21D21A0501 John Doe JOHN DOE john@ex.com 9876543210 yes Accenture -
              </pre>
            </div>
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Important</AlertTitle>
              <AlertDescription>
                Make sure your file is saved as CSV (Comma Separated Values) or TSV (Tab Separated Values) format. The
                system will attempt to detect the delimiter automatically.
              </AlertDescription>
            </Alert>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Import Template</CardTitle>
          <CardDescription>Download a template CSV file to use for importing students.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-medium">Student Import Template</h3>
              <p className="text-sm text-muted-foreground">
                This template contains all required fields for importing student data.
              </p>
            </div>
            <Button onClick={handleDownloadTemplate}>
              <Download className="mr-2 h-4 w-4" />
              Download Template
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
