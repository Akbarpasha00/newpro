"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  mockCandidates,
  mockCompanies,
  mockOffers,
  mockDrives,
  mockDepartments,
  mockEvents,
  mockScheduledDrives,
  mockSWECOffers,
} from "@/lib/mock-data"

export default function DemoPage() {
  const [activeTab, setActiveTab] = useState("candidates")

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">CMS Design Demo</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Total Candidates</CardTitle>
            <CardDescription>All registered candidates</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{mockCandidates.length}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Total Companies</CardTitle>
            <CardDescription>Registered companies</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{mockCompanies.length}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Active Offers</CardTitle>
            <CardDescription>Current job offers</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{mockOffers.filter((o) => o.status === "Open").length}</p>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-4 md:grid-cols-8 mb-4">
          <TabsTrigger value="candidates">Candidates</TabsTrigger>
          <TabsTrigger value="companies">Companies</TabsTrigger>
          <TabsTrigger value="offers">Offers</TabsTrigger>
          <TabsTrigger value="drives">Drives</TabsTrigger>
          <TabsTrigger value="departments">Departments</TabsTrigger>
          <TabsTrigger value="events">Events</TabsTrigger>
          <TabsTrigger value="scheduledDrives">Scheduled Drives</TabsTrigger>
          <TabsTrigger value="swecOffers">SWEC Offers</TabsTrigger>
        </TabsList>

        <TabsContent value="candidates">
          <Card>
            <CardHeader>
              <CardTitle>Candidates</CardTitle>
              <CardDescription>List of all registered candidates</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Name</th>
                      <th className="text-left p-2">Email</th>
                      <th className="text-left p-2">Branch</th>
                      <th className="text-left p-2">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockCandidates.map((candidate) => (
                      <tr key={candidate._id} className="border-b hover:bg-gray-50">
                        <td className="p-2">{candidate.name}</td>
                        <td className="p-2">{candidate.email}</td>
                        <td className="p-2">{candidate.branch}</td>
                        <td className="p-2">{candidate.offerStatus || "Active"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="companies">
          <Card>
            <CardHeader>
              <CardTitle>Companies</CardTitle>
              <CardDescription>List of all registered companies</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {mockCompanies.map((company) => (
                  <Card key={company._id}>
                    <CardHeader>
                      <CardTitle>{company.name}</CardTitle>
                      <CardDescription>{company.industry}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p>
                        <strong>Location:</strong> {company.location}
                      </p>
                      <p>
                        <strong>Employees:</strong> {company.employees}
                      </p>
                      <p>
                        <strong>Open Positions:</strong> {company.openPositions}
                      </p>
                      <p className="mt-2">{company.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="offers">
          <Card>
            <CardHeader>
              <CardTitle>Offers</CardTitle>
              <CardDescription>List of all job offers</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Title</th>
                      <th className="text-left p-2">Company</th>
                      <th className="text-left p-2">Location</th>
                      <th className="text-left p-2">Salary</th>
                      <th className="text-left p-2">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockOffers.map((offer) => (
                      <tr key={offer._id} className="border-b hover:bg-gray-50">
                        <td className="p-2">{offer.title}</td>
                        <td className="p-2">{offer.companyName}</td>
                        <td className="p-2">{offer.location}</td>
                        <td className="p-2">{offer.salary}</td>
                        <td className="p-2">{offer.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="drives">
          <Card>
            <CardHeader>
              <CardTitle>Drives</CardTitle>
              <CardDescription>List of all recruitment drives</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Company</th>
                      <th className="text-left p-2">Date</th>
                      <th className="text-left p-2">Location</th>
                      <th className="text-left p-2">Positions</th>
                      <th className="text-left p-2">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockDrives.map((drive) => (
                      <tr key={drive._id} className="border-b hover:bg-gray-50">
                        <td className="p-2">{drive.companyName}</td>
                        <td className="p-2">{drive.date.toLocaleDateString()}</td>
                        <td className="p-2">{drive.location}</td>
                        <td className="p-2">
                          {Array.isArray(drive.positions) ? drive.positions.join(", ") : drive.positions}
                        </td>
                        <td className="p-2">{drive.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="departments">
          <Card>
            <CardHeader>
              <CardTitle>Departments</CardTitle>
              <CardDescription>List of all departments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Name</th>
                      <th className="text-left p-2">Code</th>
                      <th className="text-left p-2">Head of Department</th>
                      <th className="text-left p-2">Description</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockDepartments.map((department) => (
                      <tr key={department._id} className="border-b hover:bg-gray-50">
                        <td className="p-2">{department.name}</td>
                        <td className="p-2">{department.code}</td>
                        <td className="p-2">{department.headOfDept}</td>
                        <td className="p-2">{department.description}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="events">
          <Card>
            <CardHeader>
              <CardTitle>Events</CardTitle>
              <CardDescription>List of all events</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Title</th>
                      <th className="text-left p-2">Type</th>
                      <th className="text-left p-2">Date</th>
                      <th className="text-left p-2">Location</th>
                      <th className="text-left p-2">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockEvents.map((event) => (
                      <tr key={event._id} className="border-b hover:bg-gray-50">
                        <td className="p-2">{event.title}</td>
                        <td className="p-2">{event.type}</td>
                        <td className="p-2">{event.startDate.toLocaleDateString()}</td>
                        <td className="p-2">{event.location}</td>
                        <td className="p-2">{event.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="scheduledDrives">
          <Card>
            <CardHeader>
              <CardTitle>Scheduled Drives</CardTitle>
              <CardDescription>List of all scheduled recruitment drives</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Company</th>
                      <th className="text-left p-2">Date</th>
                      <th className="text-left p-2">Location</th>
                      <th className="text-left p-2">Rounds</th>
                      <th className="text-left p-2">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockScheduledDrives.map((drive) => (
                      <tr key={drive._id} className="border-b hover:bg-gray-50">
                        <td className="p-2">{drive.companyName}</td>
                        <td className="p-2">{drive.date.toLocaleDateString()}</td>
                        <td className="p-2">{drive.location}</td>
                        <td className="p-2">{drive.rounds}</td>
                        <td className="p-2">{drive.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="swecOffers">
          <Card>
            <CardHeader>
              <CardTitle>SWEC Offers</CardTitle>
              <CardDescription>List of all SWEC offers</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Student Name</th>
                      <th className="text-left p-2">Roll Number</th>
                      <th className="text-left p-2">Branch</th>
                      <th className="text-left p-2">Company</th>
                      <th className="text-left p-2">Package</th>
                      <th className="text-left p-2">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockSWECOffers.map((offer) => (
                      <tr key={offer._id} className="border-b hover:bg-gray-50">
                        <td className="p-2">{offer.studentName}</td>
                        <td className="p-2">{offer.rollNumber}</td>
                        <td className="p-2">{offer.branch}</td>
                        <td className="p-2">{offer.companyName}</td>
                        <td className="p-2">{offer.package}</td>
                        <td className="p-2">{offer.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
