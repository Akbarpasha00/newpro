import type { NextAuthOptions } from "next-auth"
import { getServerSession } from "next-auth/next"
import CredentialsProvider from "next-auth/providers/credentials"
import { UserRole } from "@/constants/roles"

// Mock admin user
const mockAdmin = {
  id: "admin-id",
  name: "Admin User",
  email: "admin@example.com",
  role: UserRole.ADMIN,
}

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          throw new Error("Email and password are required")
        }

        // For demo purposes, accept any credentials with admin@example.com
        if (credentials.email.toLowerCase() === "admin@example.com") {
          return {
            id: mockAdmin.id,
            name: mockAdmin.name,
            email: mockAdmin.email,
            role: mockAdmin.role,
          }
        }

        // If we get here, the credentials are invalid
        throw new Error("Invalid email or password")
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id
        token.role = user.role
      }
      return token
    },
    async session({ session, token }) {
      if (token) {
        session.user.id = token.id as string
        session.user.role = token.role as string
      }
      return session
    },
  },
  pages: {
    signIn: "/login",
    error: "/login", // Redirect to login page on error
  },
  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },
  debug: process.env.NODE_ENV === "development", // Enable debug mode in development
  secret: process.env.NEXTAUTH_SECRET || "demo-secret-key",
}

// Helper function to get session on server components
export async function auth() {
  return await getServerSession(authOptions)
}

// Helper function to check if user has required role
export function hasRequiredRole(session: any, requiredRoles: UserRole[]) {
  if (!session || !session.user || !session.user.role) {
    return false
  }

  return requiredRoles.includes(session.user.role)
}
